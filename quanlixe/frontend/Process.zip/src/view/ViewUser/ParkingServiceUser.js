import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../../css/ParkingServiceUser.css'; // Import CSS file

function ParkingServiceUser() {
    const [services, setServices] = useState([]);
    const [vehicles, setVehicles] = useState([]);
    const [selectedService, setSelectedService] = useState(null);
    const [filteredVehicles, setFilteredVehicles] = useState([]);
    const [selectedVehicle, setSelectedVehicle] = useState(null);
    const [subscriptionDetails, setSubscriptionDetails] = useState({
        startDate: '',
        endDate: ''
    });
    const [searchQuery, setSearchQuery] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [modalMessage, setModalMessage] = useState('');

    useEffect(() => {
        const fetchServices = async () => {
            const token = localStorage.getItem('token');
            try {
                const response = await axios.get('/api/users/parking-services', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setServices(response.data);
            } catch (error) {
                console.error('Error fetching services:', error);
                showAlert('Failed to load services.');
            }
        };

        const fetchVehicles = async () => {
            const token = localStorage.getItem('token');
            try {
                const response = await axios.get('/api/users/vehicles', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setVehicles(response.data);
            } catch (error) {
                console.error('Error fetching vehicles:', error);
                showAlert('Failed to load vehicles.');
            }
        };

        fetchServices();
        fetchVehicles();
    }, []);

    const handleSelectService = (serviceId, applicableType, durationMonths) => {
        setSelectedService(serviceId);
        const filtered = vehicles.filter(vehicle => vehicle.type === applicableType);
        setFilteredVehicles(filtered);

        const startDate = new Date();
        const endDate = new Date();
        endDate.setMonth(endDate.getMonth() + durationMonths);

        setSubscriptionDetails({
            startDate: startDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0]
        });
    };

    const showAlert = (message) => {
        setModalMessage(message);
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setModalMessage('');
    };

    const handleSubscribe = async () => {
        if (!selectedVehicle) {
            showAlert('Please select a vehicle first.');
            return;
        }

        const token = localStorage.getItem('token');
        try {
            await axios.post(
                `/api/users/subscribe-service/${selectedService}?vehicleId=${selectedVehicle}`,
                {},
                { headers: { Authorization: `Bearer ${token}` } }
            );
            showAlert(`Đăng ký dịch vụ thành công`);
        } catch (error) {
            showAlert(`Đăng ký dịch vụ thất bại `);
        }
    };

    const filteredServices = services.filter(service =>
        service.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="parking-service-container">
            <h2>Dịch Vụ Bãi Đỗ Xe Có Sẵn</h2>
            {showModal && (
                <>
                    <div className="modal-overlay" onClick={closeModal}></div>
                    <div className="modal">
                        <p>{modalMessage}</p>
                        <button onClick={closeModal}>Close</button>
                    </div>
                </>
            )}
            <input
                type="text"
                placeholder="Tìm Dịch Vụ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
            />
            <div className="service-grid">
                {filteredServices.map((service) => (
                    <div key={service.id} className="service-card">
                        <h4>{service.name}</h4>
                        <p>Chi Phí: ${service.price}</p>
                        <p>Thời Hạn: {service.durationMonths} Tháng</p>
                        <p>Áp Dụng Cho :  
                        {service.applicableType === "MOTORBIKE" ? "  Xe máy" : 
                        service.applicableType === "CAR" ? "  Ô tô" : " Xe đạp"}
                        </p>
                        <button
                            className="select-button"
                            onClick={() => handleSelectService(service.id, service.applicableType, service.durationMonths)}
                        >
                           Chọn Dịch Vụ
                        </button>
                        {selectedService === service.id && (
                            <div>
                                <h4>Chọn Xe của bạn</h4>
                                {filteredVehicles.length > 0 ? (
                                    <select
                                        onChange={(e) => setSelectedVehicle(e.target.value)}
                                        className="vehicle-select"
                                    >
                                        <option value="">-- Chọn Xe Đã Xác Nhận --</option>
                                        {filteredVehicles.map((vehicle) => (
                                            <option key={vehicle.id} value={vehicle.id}>
                                                {vehicle.licensePlate} ({vehicle.applicableType === "MOTORBIKE" ? "  Xe máy" : 
                        vehicle.applicableType === "CAR" ? "  Ô tô" : " Xe đạp"})
                                            </option>
                                        ))}
                                    </select>
                                ) : (
                                    <p>No vehicles available for this service type.</p>
                                )}

                                {selectedVehicle && (
                                    <div>
                                        <h4>Thời Gian Dịch Vụ</h4>
                                        <p>Ngày Bắt Đầu: {subscriptionDetails.startDate}</p>
                                        <p>Ngày Kết Thúc: {subscriptionDetails.endDate}</p>
                                        <button className="confirm-button" onClick={handleSubscribe}>
                                           Xác Nhận
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default ParkingServiceUser;
