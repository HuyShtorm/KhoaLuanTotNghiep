import React from 'react'

function MyVehicleHistory() {
  return (
    <div>MyVehicleHistory</div>
  )
}

export default MyVehicleHistory