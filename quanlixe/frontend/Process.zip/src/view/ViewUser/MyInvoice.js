import React from 'react'

function MyInvoice() {
  return (
    <div>MyInvoice</div>
  )
}

export default MyInvoice