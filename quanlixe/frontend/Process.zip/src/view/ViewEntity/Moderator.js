import React from 'react'

function Moderator() {
  return (
    <div>Moderator</div>
  )
}

export default Moderator