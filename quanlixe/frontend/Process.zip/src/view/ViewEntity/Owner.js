import React from 'react'

function Owner() {
  return (
    <div>Owner</div>
  )
}

export default Owner