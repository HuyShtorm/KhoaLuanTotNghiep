// Dashboard.js
import React from 'react';

const Dashboard = () => {
  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <p>Thông tin tổng quan về xe ra vào, chỗ trống trong bãi đỗ, và thống kê.</p>
    </div>
  );
};

export default Dashboard;
