import React from 'react'

function Parkingmap() {
  return (
    <div>Parkingmap</div>
  )
}

export default Parkingmap