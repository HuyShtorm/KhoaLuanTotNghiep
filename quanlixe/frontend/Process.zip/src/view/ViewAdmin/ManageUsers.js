import React from 'react'

function ManageUsers() {
  return (
    <div>Manageusers</div>
  )
}

export default ManageUsers