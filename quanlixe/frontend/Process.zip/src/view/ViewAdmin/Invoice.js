import React from 'react'

function Invoice() {
  return (
    <div>Invoice</div>
  )
}

export default Invoice