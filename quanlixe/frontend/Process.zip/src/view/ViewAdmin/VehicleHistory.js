import React from 'react'

function Vehiclehistory() {
  return (
    <div>Vehiclehistory</div>
  )
}

export default Vehiclehistory